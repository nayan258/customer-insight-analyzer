'use client';

import React, { useState, useRef, useEffect } from 'react';
import { UploadCloud, FileText, BarChart2, CheckCircle, Database, AlertCircle, TrendingUp, Presentation, Download, MessageSquare, Loader2, Sparkles } from 'lucide-react';
import { parseFile, cleanData, calculateStats, Dataset, DataStats, simpleLinearRegression } from '@/lib/data-processing';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import Markdown from 'react-markdown';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316'];

export default function Dashboard() {
  const [file, setFile] = useState<File | null>(null);
  const [originalDataset, setOriginalDataset] = useState<Dataset | null>(null);
  const [dataset, setDataset] = useState<Dataset | null>(null);
  const [stats, setStats] = useState<DataStats | null>(null);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<'overview' | 'visualize' | 'ml' | 'insights'>('overview');

  const [aiInsights, setAiInsights] = useState<string | null>(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  const [nlQuery, setNlQuery] = useState('');
  const [queryResult, setQueryResult] = useState<string | null>(null);
  const [loadingQuery, setLoadingQuery] = useState(false);

  const [xAxis, setXAxis] = useState<string>('');
  const [yAxis, setYAxis] = useState<string>('');
  const [chartType, setChartType] = useState<'bar' | 'line'>('bar');

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    setLoading(true);
    setError(null);
    try {
      const parsed = await parseFile(selectedFile);
      setFile(selectedFile);
      setOriginalDataset(parsed);
      const cleaned = cleanData(parsed);
      setDataset(cleaned);
      const calculatedStats = calculateStats(cleaned);
      setStats(calculatedStats);
      
      const numerics = Object.keys(calculatedStats).filter(k => calculatedStats[k].type === 'numeric');
      const strings = Object.keys(calculatedStats).filter(k => calculatedStats[k].type === 'string');
      
      if (numerics.length > 0 && strings.length > 0) {
        setXAxis(strings[0]);
        setYAxis(numerics[0]);
      } else if (numerics.length >= 2) {
        setXAxis(numerics[0]);
        setYAxis(numerics[1]);
      }
      setActiveTab('overview');
      setAiInsights(null);
      setQueryResult(null);
      setNlQuery('');
    } catch (err: any) {
      setError(err.message || "Error processing file");
    } finally {
      setLoading(false);
    }
  };

  const generateInsights = async () => {
    if (!stats) return;
    setLoadingInsights(true);
    try {
      const res = await fetch('/api/insights', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          stats,
          promptContext: "Generate overall business insights, identify anomalies, and provide strategic recommendations."
        })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setAiInsights(data.insight);
    } catch (err: any) {
      setError("Failed to generate AI insights: " + err.message);
    } finally {
      setLoadingInsights(false);
    }
  };

  const handleNlQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nlQuery.trim() || !stats) return;
    setLoadingQuery(true);
    try {
      const res = await fetch('/api/query', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ stats, query: nlQuery })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setQueryResult(data.answer);
    } catch (err: any) {
      setError("AI Query Error: " + err.message);
    } finally {
      setLoadingQuery(false);
    }
  };

  const downloadReportPDF = () => {
    if (!dataset || !stats) return;
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text("AI Business Analysis Report", 14, 22);
    
    doc.setFontSize(14);
    doc.text("1. Data Summary", 14, 35);
    
    doc.setFontSize(10);
    doc.text(`Rows parsed: ${originalDataset?.data.length || 0}`, 14, 45);
    doc.text(`Clean rows: ${dataset.data.length || 0}`, 14, 52);
    doc.text(`Columns: ${dataset.headers.length || 0}`, 14, 59);

    let yOffset = 70;
    
    const tableBody = Object.keys(stats).map(col => {
      const s = stats[col];
      return [col, s.type, s.count, s.unique || '-', s.mean?.toFixed(2) || '-'];
    });

    autoTable(doc, {
      startY: yOffset,
      head: [['Column', 'Type', 'Count', 'Unique', 'Mean']],
      body: tableBody as any,
    });

    if (aiInsights) {
      doc.addPage();
      doc.setFontSize(14);
      doc.text("2. AI Business Insights", 14, 22);
      doc.setFontSize(10);
      const splitLines = doc.splitTextToSize(aiInsights, 180);
      doc.text(splitLines, 14, 35);
    }

    doc.save("analysis_report.pdf");
  };

  const getChartData = () => {
    if (!dataset || !xAxis || !yAxis) return [];
    
    const aggregated: Record<string, number> = {};
    const limit = 100; // Limit for performance if huge cardinality
    dataset.data.forEach(row => {
      const xVal = String(row[xAxis] || 'Unknown');
      const yVal = Number(row[yAxis] || 0);
      aggregated[xVal] = (aggregated[xVal] || 0) + yVal;
    });

    let result = Object.keys(aggregated).map(k => ({
      name: k,
      value: aggregated[k]
    }));

    if (stats?.[xAxis]?.type === 'string') {
        result = result.sort((a,b) => b.value - a.value).slice(0, 15);
    } else {
        result = result.slice(0, limit);
    }

    return result;
  };

  const getRegressionData = () => {
    if(!dataset || !stats) return { data: [], eq: '' };
    const numerics = Object.keys(stats).filter(k => stats[k].type === 'numeric');
    if (numerics.length < 2) return { data: [], eq: 'Not enough numeric columns' };
    
    const xCol = numerics[0];
    const yCol = numerics[1];
    
    const validData = dataset.data.filter(r => !isNaN(Number(r[xCol])) && !isNaN(Number(r[yCol])));
    const xVals = validData.map(r => Number(r[xCol]));
    const yVals = validData.map(r => Number(r[yCol]));
    
    const { slope, intercept, predict } = simpleLinearRegression(xVals, yVals);
    
    const data = validData.map(r => ({
      [xCol]: Number(r[xCol]),
      Actual: Number(r[yCol]),
      Predicted: predict(Number(r[xCol]))
    })).sort((a, b) => a[xCol] - b[xCol]);
    
    return {
      data,
      xCol,
      yCol,
      eq: `y = ${slope.toFixed(4)}x ${intercept >= 0 ? '+' : ''} ${intercept.toFixed(4)}`
    };
  };

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-neutral-200 px-6 py-4 sticky top-0 z-10 flex justify-between items-center shadow-sm">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <BarChart2 className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600 tracking-tight">
            AI Sales & Customer Insight Analyzer
          </h1>
        </div>
        {dataset && (
          <button 
            onClick={downloadReportPDF}
            className="flex items-center gap-2 text-sm font-medium px-4 py-2 bg-neutral-900 text-white rounded-md hover:bg-neutral-800 transition-colors"
          >
            <Download className="w-4 h-4" /> Download Report
          </button>
        )}
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {!dataset && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="bg-white border text-center border-neutral-200 border-dashed rounded-xl p-12 max-w-xl w-full shadow-sm hover:shadow-md transition-shadow">
              <UploadCloud className="w-12 h-12 text-blue-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-2">Upload Dataset</h2>
              <p className="text-neutral-500 mb-6 font-medium">Upload a CSV or Excel file to begin AI analysis.</p>
              <label className="cursor-pointer bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors shadow-sm inline-flex items-center gap-2">
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <FileText className="w-5 h-5" />}
                {loading ? 'Processing...' : 'Select File'}
                <input type="file" accept=".csv,.xlsx" className="hidden" onChange={handleFileUpload} disabled={loading} />
              </label>
              {error && <div className="mt-4 text-red-500 flex items-center justify-center gap-2 font-medium"><AlertCircle className="w-4 h-4" /> {error}</div>}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 max-w-4xl text-left">
              <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-sm">
                <Database className="w-6 h-6 text-indigo-500 mb-3" />
                <h3 className="font-semibold text-lg mb-1">Data Cleaning</h3>
                <p className="text-sm text-neutral-500">Automatically handles missing values, detects column types, and removes duplicates on upload.</p>
              </div>
              <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-sm">
                <Presentation className="w-6 h-6 text-emerald-500 mb-3" />
                <h3 className="font-semibold text-lg mb-1">Visualizations</h3>
                <p className="text-sm text-neutral-500">Explore interactive plot configurations and visualize trends instantly without code.</p>
              </div>
              <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-sm">
                <Sparkles className="w-6 h-6 text-amber-500 mb-3" />
                <h3 className="font-semibold text-lg mb-1">AI Insights</h3>
                <p className="text-sm text-neutral-500">Utilize Gemini AI to summarize trends, explain drop-offs, and recommend business actions.</p>
              </div>
            </div>
          </div>
        )}

        {dataset && stats && (
          <div className="flex flex-col gap-6">
            
            {/* Context Bar */}
            <div className="flex items-center gap-4 bg-white px-5 py-3 rounded-lg border border-neutral-200 shadow-sm text-sm">
              <div className="flex items-center gap-2 font-medium text-emerald-600">
                <CheckCircle className="w-4 h-4" /> Data Cleaned
              </div>
              <div className="h-4 w-px bg-neutral-300"></div>
              <div className="text-neutral-600">Original Rows: <b>{originalDataset?.data.length}</b></div>
              <div className="h-4 w-px bg-neutral-300"></div>
              <div className="text-neutral-600">Clean Rows: <b>{dataset.data.length}</b></div>
              <div className="h-4 w-px bg-neutral-300"></div>
              <div className="text-neutral-600">Columns Detected: <b>{dataset.headers.length}</b></div>
            </div>

            {/* Navigation Tabs */}
            <nav className="flex gap-2 border-b border-neutral-200 pb-1">
              {[
                { id: 'overview', label: 'Data Overview', icon: Database },
                { id: 'visualize', label: 'Visualizations', icon: Presentation },
                { id: 'ml', label: 'Predictive ML', icon: TrendingUp },
                { id: 'insights', label: 'AI Strategy', icon: Sparkles }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-t-lg font-medium text-sm transition-all border-b-2 ${
                    activeTab === tab.id 
                      ? 'border-blue-600 text-blue-700 bg-blue-50/50' 
                      : 'border-transparent text-neutral-500 hover:text-neutral-800 hover:bg-neutral-50'
                  }`}
                >
                  <tab.icon className="w-4 h-4" /> {tab.label}
                </button>
              ))}
            </nav>

            {/* Tab Contents */}
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
              
              {/* OVERVIEW TAB */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                     {Object.keys(stats).slice(0, 8).map(key => {
                        const s = stats[key];
                        return (
                          <div key={key} className="bg-white border border-neutral-200 p-4 rounded-xl shadow-sm">
                            <h4 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider truncate" title={key}>{key}</h4>
                            <div className="mt-1 flex items-baseline gap-2">
                              <span className="text-2xl font-bold text-neutral-900">
                                {s.type === 'numeric' && s.mean ? s.mean.toFixed(1) : s.unique}
                              </span>
                              <span className="text-xs text-neutral-500">{s.type === 'numeric' ? 'Avg' : 'Unique Vals'}</span>
                            </div>
                          </div>
                        )
                     })}
                  </div>
                  
                  <div className="bg-white border border-neutral-200 rounded-xl shadow-sm overflow-hidden flex flex-col h-[500px]">
                    <div className="px-5 py-3 border-b border-neutral-200 bg-neutral-50 font-semibold text-neutral-700">Preview Data</div>
                    <div className="overflow-auto flex-1 p-0">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-neutral-500 bg-white sticky top-0 uppercase bg-opacity-95 backdrop-blur shadow-sm">
                          <tr>
                            {dataset.headers.slice(0,10).map((h, i) => (
                              <th key={i} className="px-5 py-3 font-medium border-b border-neutral-200 whitespace-nowrap">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {dataset.data.slice(0, 50).map((row, i) => (
                            <tr key={i} className="bg-white border-b border-neutral-100 hover:bg-neutral-50">
                              {dataset.headers.slice(0,10).map((h, j) => (
                                <td key={j} className="px-5 py-2.5 truncate max-w-xs">{String(row[h] || '')}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* VISUALIZATIONS TAB */}
              {activeTab === 'visualize' && (
                <div className="bg-white border border-neutral-200 rounded-xl shadow-sm p-6">
                  <div className="flex flex-col md:flex-row gap-6 mb-8">
                    <div className="flex-1 space-y-4">
                      <div>
                        <label className="block text-sm font-semibold text-neutral-700 mb-1">X-Axis (Dimension)</label>
                        <select className="w-full p-2 border border-neutral-300 rounded-md bg-white text-sm" value={xAxis} onChange={e => setXAxis(e.target.value)}>
                          <option value="">Select...</option>
                          {dataset.headers.map(h => <option key={h} value={h}>{h}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-neutral-700 mb-1">Y-Axis (Metrics/Sum)</label>
                        <select className="w-full p-2 border border-neutral-300 rounded-md bg-white text-sm" value={yAxis} onChange={e => setYAxis(e.target.value)}>
                          <option value="">Select...</option>
                          {Object.keys(stats).filter(k => stats[k].type === 'numeric').map(h => <option key={h} value={h}>{h}</option>)}
                        </select>
                      </div>
                      <div className="pt-2">
                         <label className="block text-sm font-semibold text-neutral-700 mb-2">Chart Type</label>
                         <div className="flex border border-neutral-200 rounded-md divide-x divide-neutral-200 bg-neutral-50 overflow-hidden w-fit">
                           <button onClick={() => setChartType('bar')} className={`px-4 py-1.5 text-sm font-medium ${chartType==='bar' ? 'bg-white text-blue-600 shadow-sm' : 'text-neutral-500'}`}>Bar</button>
                           <button onClick={() => setChartType('line')} className={`px-4 py-1.5 text-sm font-medium ${chartType==='line' ? 'bg-white text-blue-600 shadow-sm' : 'text-neutral-500'}`}>Line</button>
                         </div>
                      </div>
                    </div>
                    <div className="flex-[3] h-[400px]">
                      {xAxis && yAxis && (
                        <ResponsiveContainer width="100%" height="100%">
                          {chartType === 'bar' ? (
                            <BarChart data={getChartData()} margin={{ top: 10, right: 30, left: 0, bottom: 30 }}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                              <XAxis dataKey="name" tick={{fontSize: 12}} tickMargin={10} minTickGap={20} />
                              <YAxis tick={{fontSize: 12}} />
                              <RechartsTooltip cursor={{fill: '#f3f4f6'}} contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
                              <Legend />
                              <Bar dataKey="value" name={yAxis} fill="#3b82f6" radius={[4, 4, 0, 0]} />
                            </BarChart>
                          ) : (
                            <LineChart data={getChartData()} margin={{ top: 10, right: 30, left: 0, bottom: 30 }}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                              <XAxis dataKey="name" tick={{fontSize: 12}} tickMargin={10} minTickGap={20} />
                              <YAxis tick={{fontSize: 12}} />
                              <RechartsTooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
                              <Legend />
                              <Line type="monotone" dataKey="value" name={yAxis} stroke="#3b82f6" strokeWidth={3} dot={{r: 4, strokeWidth: 2}} activeDot={{r: 6}} />
                            </LineChart>
                          )}
                        </ResponsiveContainer>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* MACHINE LEARNING TAB */}
              {activeTab === 'ml' && (() => {
                const reg = getRegressionData();
                return (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white border border-neutral-200 rounded-xl shadow-sm p-6 flex flex-col">
                       <h3 className="font-semibold flex items-center gap-2 mb-1"><TrendingUp className="w-5 h-5 text-indigo-500"/> Linear Regression Simulator</h3>
                       <p className="text-sm text-neutral-500 mb-6">Predicts numeric target based on correlations.</p>
                       
                       {reg.data.length > 0 ? (
                         <>
                           <div className="bg-neutral-50 border border-neutral-200 px-4 py-3 rounded-lg mb-6 font-mono text-sm text-indigo-800 font-medium overflow-auto">
                              Equation: {reg.eq}
                           </div>
                           <div className="flex-1 min-h-[300px]">
                              <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={reg.data.slice(0, 50)} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                  <XAxis dataKey={reg.xCol} tick={{fontSize: 12}} />
                                  <YAxis tick={{fontSize: 12}} />
                                  <RechartsTooltip />
                                  <Legend />
                                  <Line type="monotone" dataKey="Actual" stroke="#94a3b8" strokeWidth={2} dot={false} />
                                  <Line type="monotone" dataKey="Predicted" stroke="#6366f1" strokeWidth={3} dot={false} />
                                </LineChart>
                              </ResponsiveContainer>
                           </div>
                         </>
                       ) : (
                         <div className="flex-1 flex items-center justify-center text-sm text-neutral-500 bg-neutral-50 rounded-lg border border-neutral-100">
                           {reg.eq} (Minimum 2 numeric cols required)
                         </div>
                       )}
                    </div>

                    <div className="bg-white border border-neutral-200 rounded-xl shadow-sm p-6 flex flex-col">
                       <h3 className="font-semibold flex items-center gap-2 mb-1"><Database className="w-5 h-5 text-rose-500"/> Top Segments</h3>
                       <p className="text-sm text-neutral-500 mb-6">Categorical clustering & top segment distribution.</p>
                       
                       <div className="flex-1 flex items-center justify-center min-h-[300px]">
                         {stats && Object.keys(stats).find(k => stats[k].type === 'string' && stats[k].topValues && stats[k].topValues!.length > 0) ? (() => {
                             const catCol = Object.keys(stats).find(k => stats[k].type === 'string' && stats[k].topValues)!;
                             const data = stats[catCol].topValues || [];
                             return (
                               <div className="w-full h-full flex flex-col">
                                 <div className="text-center text-sm font-semibold text-neutral-700 mb-2">Distribution: {catCol}</div>
                                 <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                      <Pie
                                        data={data}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={60}
                                        outerRadius={80}
                                        paddingAngle={5}
                                        dataKey="count"
                                        nameKey="value"
                                      >
                                        {data.map((entry, index) => (
                                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                        ))}
                                      </Pie>
                                      <RechartsTooltip />
                                      <Legend />
                                    </PieChart>
                                 </ResponsiveContainer>
                               </div>
                             );
                         })() : (
                           <div className="text-sm text-neutral-500">No suitable categorical columns found.</div>
                         )}
                       </div>
                    </div>
                  </div>
                );
              })()}

              {/* AI INSIGHTS & CHAT TAB */}
              {activeTab === 'insights' && (
                 <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                   {/* Left: AI Report Generate */}
                   <div className="lg:col-span-3 bg-gradient-to-br from-white to-neutral-50 border border-neutral-200 rounded-xl shadow-sm p-6 flex flex-col h-full min-h-[600px]">
                      <div className="flex justify-between items-center mb-6 pb-4 border-b border-neutral-100">
                         <div>
                           <h3 className="font-bold text-lg text-neutral-900 flex items-center gap-2"><Sparkles className="w-5 h-5 text-amber-500"/> Strategic Analysis</h3>
                           <p className="text-sm text-neutral-500">Gemini 3.5 AI automates deep dives into your stats.</p>
                         </div>
                         {!aiInsights && !loadingInsights && (
                           <button onClick={generateInsights} className="bg-neutral-900 hover:bg-neutral-800 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-sm transition-colors">
                             Generate Report
                           </button>
                         )}
                      </div>

                      <div className="flex-1 overflow-auto">
                        {loadingInsights ? (
                           <div className="flex flex-col items-center justify-center h-full text-neutral-500">
                             <Loader2 className="w-8 h-8 animate-spin mb-4 text-amber-500" />
                             <p className="font-medium">Analyzing statistical signatures...</p>
                           </div>
                        ) : aiInsights ? (
                           <div className="prose prose-sm prose-neutral max-w-none">
                              <Markdown>{aiInsights}</Markdown>
                           </div>
                        ) : (
                           <div className="flex flex-col items-center justify-center h-full text-neutral-400">
                             <FileText className="w-12 h-12 mb-3 opacity-20" />
                             <p>Run generation to view business strategy.</p>
                           </div>
                        )}
                      </div>
                   </div>

                   {/* Right: Natural Language Query */}
                   <div className="lg:col-span-2 bg-white border border-neutral-200 rounded-xl shadow-sm flex flex-col h-full min-h-[500px]">
                      <div className="px-5 py-4 border-b border-neutral-200 bg-neutral-50 rounded-t-xl">
                        <h3 className="font-semibold text-neutral-900 flex items-center gap-2"><MessageSquare className="w-4 h-4 text-blue-600"/> Data Co-pilot</h3>
                        <p className="text-xs text-neutral-500 mt-1">Ask questions about your dataset trends.</p>
                      </div>
                      
                      <div className="flex-1 p-5 overflow-auto flex flex-col justify-end bg-neutral-50/50">
                        {queryResult && (
                           <div className="mb-6 bg-blue-50 border border-blue-100 p-4 rounded-xl text-sm text-neutral-800 shadow-sm animate-in fade-in slide-in-from-bottom-2">
                             <Markdown className="prose prose-sm font-medium">{queryResult}</Markdown>
                           </div>
                        )}
                        {loadingQuery && (
                           <div className="flex gap-2 items-center text-sm text-blue-600 mb-6 bg-blue-50/50 p-4 rounded-xl w-fit">
                              <Loader2 className="w-4 h-4 animate-spin" /> Thinking...
                           </div>
                        )}
                      </div>

                      <form onSubmit={handleNlQuery} className="p-4 border-t border-neutral-200 bg-white rounded-b-xl">
                         <div className="relative">
                            <input
                              type="text"
                              value={nlQuery}
                              onChange={e => setNlQuery(e.target.value)}
                              placeholder='e.g. "Which product has the highest mean?"'
                              className="w-full bg-neutral-100 border-transparent focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-lg pl-4 pr-12 py-3 text-sm transition-all"
                              required
                            />
                            <button type="submit" disabled={loadingQuery} className="absolute right-2 top-2 bottom-2 text-white bg-blue-600 hover:bg-blue-700 rounded-md px-3 flex items-center justify-center transition-colors shadow-sm disabled:opacity-50">
                               <Sparkles className="w-4 h-4" />
                            </button>
                         </div>
                      </form>
                   </div>
                 </div>
              )}
            </div>
            
          </div>
        )}
      </main>
    </div>
  );
}
