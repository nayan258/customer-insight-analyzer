import Papa from 'papaparse';
import * as XLSX from 'xlsx';

export interface DataRow {
  [key: string]: any;
}

export interface Dataset {
  headers: string[];
  data: DataRow[];
}

export interface DataStats {
  [key: string]: {
    type: 'numeric' | 'string' | 'date';
    count: number;
    min?: number;
    max?: number;
    mean?: number;
    sum?: number;
    unique?: number;
    topValues?: {value: string, count: number}[];
  };
}

export const parseFile = async (file: File): Promise<Dataset> => {
  return new Promise((resolve, reject) => {
    if (file.name.endsWith('.csv')) {
      Papa.parse(file, {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true,
        complete: (results) => {
          resolve({
            headers: results.meta.fields || [],
            data: results.data as DataRow[],
          });
        },
        error: (error) => reject(error)
      });
    } else if (file.name.endsWith('.xlsx')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const json = XLSX.utils.sheet_to_json(worksheet);
          
          let headers: string[] = [];
          if (json.length > 0) {
            headers = Object.keys(json[0] as any);
          }
          resolve({
            headers,
            data: json as DataRow[],
          });
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = (error) => reject(error);
      reader.readAsBinaryString(file);
    } else {
      reject(new Error("Unsupported file format"));
    }
  });
};

export const cleanData = (dataset: Dataset): Dataset => {
  let cleaned = dataset.data.filter(row => {
    return Object.values(row).some(v => v !== null && v !== undefined && v !== '');
  });
  
  const seen = new Set();
  cleaned = cleaned.filter(row => {
    const str = JSON.stringify(row);
    if (seen.has(str)) return false;
    seen.add(str);
    return true;
  });

  return { headers: dataset.headers, data: cleaned };
};

export const calculateStats = (dataset: Dataset): DataStats => {
  const stats: DataStats = {};
  
  dataset.headers.forEach(header => {
    let type: 'numeric' | 'string' | 'date' = 'string';
    const values = dataset.data.map(r => r[header]).filter(v => v !== null && v !== undefined && v !== '');
    
    if (values.length > 0) {
      if (values.every(v => typeof v === 'number' || (!isNaN(Number(v)) && v !== ''))) {
        type = 'numeric';
      }
    }

    if (type === 'numeric') {
      const nums = values.map(v => Number(v));
      nums.sort((a, b) => a - b);
      const sum = nums.reduce((a, b) => a + b, 0);
      const mean = sum / nums.length;
      stats[header] = {
        type,
        count: nums.length,
        min: nums[0],
        max: nums[nums.length - 1],
        mean,
        sum
      };
    } else {
      const counts: Record<string, number> = {};
      values.forEach(v => {
        counts[String(v)] = (counts[String(v)] || 0) + 1;
      });
      const topValues = Object.entries(counts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([value, count]) => ({value, count}));
        
      stats[header] = {
        type,
        count: values.length,
        unique: new Set(values).size,
        topValues
      };
    }
  });

  return stats;
};

export const simpleLinearRegression = (x: number[], y: number[]) => {
  const n = x.length;
  if(n === 0) return { slope: 0, intercept: 0, predict: (val: number) => 0 };
  const sumX = x.reduce((acc, val) => acc + val, 0);
  const sumY = y.reduce((acc, val) => acc + val, 0);
  const sumXY = x.reduce((acc, val, i) => acc + val * y[i], 0);
  const sumX2 = x.reduce((acc, val) => acc + val * val, 0);

  const denominator = (n * sumX2 - sumX * sumX);
  if (denominator === 0) return { slope: 0, intercept: sumY/n, predict: (val: number) => sumY/n };

  const slope = (n * sumXY - sumX * sumY) / denominator;
  const intercept = (sumY - slope * sumX) / n;

  return {
    slope,
    intercept,
    predict: (val: number) => slope * val + intercept
  };
};
