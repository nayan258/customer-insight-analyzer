# AI Business Sales & Customer Insight Analyzer

Welcome to the AI-powered data analysis platform!

> **Note on Environment:** This workspace strictly provides a Next.js (TypeScript) runtime. Therefore, while you requested a Python/Streamlit implementation, I have built an **exact functional match** of your requested features (auto-cleaning, EDA, interactive charts, ML regression simulation, AI insights, NL queries, and PDF downloads) using **Next.js, Recharts, and the Gemini API** directly in this web application.
> 
> However, to fulfill your request for Python structure and documentation, I have provided the conceptual Python setup steps and a `requirements.txt` below.

## Live Next.js Web App Features (Currently Running)
- 📂 **Drop-in CSV/Excel upload** with auto-cleaning and parsing (via PapaParse / XLSX)
- 📊 **Exploratory Data Analysis (EDA)** with mean, counts, and top distributions
- 📉 **Interactive Visualizations** with dynamic X/Y axis selection (via Recharts)
- 🤖 **Machine Learning Simulator** (Linear Regression & Top Segment Clustering)
- 🧠 **Gemini API Insights** for strategic reporting and anomaly detection
- 💬 **Natural Language Query** for your dataset
- 📄 **PDF Report Generation** with AutoTable (via jsPDF)

## Python / Streamlit Setup Instructions (Conceptual)
If you wish to build this locally using Python and Streamlit in the future, follow these steps:

### 1. Prerequisites
Ensure you have Python 3.9+ installed on your system.

### 2. Environment Setup
```bash
# Create a virtual environment
python -m venv venv

# Activate the virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. API Key Configuration
Create a `.env` file in the root directory and add your Google Gemini API key:
```env
GEMINI_API_KEY=your_api_key_here
```

### 5. Run the Application
```bash
streamlit run app.py
```

## Sample Dataset
A file named `sample_dataset.csv` has been provided in the root directory for testing the application.

## Modules Structure (If implemented in Python)
- `app.py`: Main Streamlit routing and UI logic.
- `data_cleaning.py`: Pandas logic for dropna, fillna, and dtype inference.
- `visualization.py`: Plotly Express wrappers.
- `ml_model.py`: Scikit-learn regressors and K-Means.
- `ai_insights.py`: Google Generative AI bindings.
