import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const { stats, query } = await req.json();
    
    const prompt = `
You are an expert Data Analyst an AI Assistant answering questions about a dataset.
A user has uploaded a dataset and asked a question in natural language.

I will provide you with the summary statistics of the dataset, and you must answer the user's question based strictly on these statistics to the best of your ability.
If the question is about asking for specific row data that you cannot see in the stats (like "Show top 5 customers"), politely explain that you only have access to high-level statistical summaries and cannot see individual rows for privacy and performance reasons, but provide the relevant aggregate information you do have (such as top values from string columns).

Dataset Statistics Overview:
${JSON.stringify(stats, null, 2)}

User Question: ${query}

Answer clearly, using markdown. Focus on the data.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });
    
    return NextResponse.json({ answer: response.text });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
