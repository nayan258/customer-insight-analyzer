import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const { stats, promptContext } = await req.json();
    
    const prompt = `
You are an expert Data Analyst and Business Strategist.
I will provide you with the summary statistics of a dataset. 

Dataset Statistics Overview:
${JSON.stringify(stats, null, 2)}

Context/Goal:
${promptContext}

Please provide:
1. Key Trends & Observations (3 bullet points)
2. Potential Issues or Anomalies (if any)
3. Actionable Business Recommendations (3 bullet points)

Keep your response professional, structured, and easy to read.
Use Markdown. Do not include raw JSON in the response.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });
    
    return NextResponse.json({ insight: response.text });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
